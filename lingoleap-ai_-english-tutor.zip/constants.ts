
export const GRAMMAR_TOPICS = [
    "All 12 English Tenses",
    "Gerunds and Infinitives",
    "Passive Voice",
    "Questions",
    "Reported Speech",
    "Relative Clauses",
    "Real/Unreal/Past Conditionals",
    "Nouns",
    "Articles",
    "Qualifiers",
    "Adjectives",
    "Adverbs",
    "Connectors",
    "Pronouns",
    "Irregular Verbs"
];
